
Alles über Knoblauch - statische Website (13 Seiten)
--------------------------------------------------

Dateien: 
- index.html, geschichte.html, wirkung.html, rezepte.html, anbau.html, sorten.html,
  lagerung.html, kombinationen.html, kultur.html, wirtschaft.html, produkte.html,
  tipps.html, galerie.html, styles.css

Deployment:
- Lokal: Ordner entpacken und index.html im Browser öffnen.
- GitHub Pages: Neues Repository anlegen, Dateien hochladen, in Settings -> Pages Branch 'main' aktivieren.
- Netlify/Vercel: Einfach das Verzeichnis deployen oder das Repository verbinden.

Hinweis zu Bildern:
- Einige Seiten nutzen externe Unsplash-URLs als Platzhalter. Für eine eigenständige Seite lade Bilder herunter und speichere sie im Ordner 'images' und passe src-Pfade an.

Viel Spaß mit deiner Knoblauch-Website!
