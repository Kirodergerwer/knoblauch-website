// Client-side search + secret password handling
const SECRET_PHRASE = "Lorik ist der gr\u00f6\u00dfte"; // exact phrase

const pages = [
  {file: "index.html", title: "Startseite"},
  {file: "geschichte.html", title: "Herkunft & Geschichte"},
  {file: "wirkung.html", title: "Gesundheit & Wirkung"},
  {file: "rezepte.html", title: "Rezepte & Küche"},
  {file: "anbau.html", title: "Anbau im Garten"},
  {file: "sorten.html", title: "Sorten"},
  {file: "lagerung.html", title: "Lagerung & Konservierung"},
  {file: "kombinationen.html", title: "Kombinationen"},
  {file: "kultur.html", title: "Kultur, Mythen & Brauchtum"},
  {file: "wirtschaft.html", title: "Wirtschaft & Anbau"},
  {file: "produkte.html", title: "Verarbeitung & Produkte"},
  {file: "tipps.html", title: "Tipps & Tricks"},
  {file: "galerie.html", title: "Galerie & Medien"}
];

function handleSearch(e) {
  e.preventDefault();
  const input = document.getElementById('site-search-input');
  if (!input) return false;
  const q = input.value.trim();
  if (!q) return false;
  // Check secret phrase (exact match)
  if (q === SECRET_PHRASE) {
    openSecretModal();
    input.value = '';
    return false;
  }
  // Otherwise simple title match (case-insensitive)
  const ql = q.toLowerCase();
  const matches = pages.filter(p => p.title.toLowerCase().includes(ql) || p.file.toLowerCase().includes(ql));
  if (matches.length === 1) {
    window.location.href = matches[0].file;
  } else if (matches.length > 1) {
    showResultsOverlay(matches);
  } else {
    showNoResults(q);
  }
  return false;
}

function showResultsOverlay(matches) {
  let html = '<div class="search-results-overlay"><div class="search-results"><h3>Suchergebnisse</h3><ul>';
  for (const m of matches) html += `<li><a href="${m.file}">${m.title}</a></li>`;
  html += '</ul><button onclick="closeResultsOverlay()">Schließen</button></div></div>';
  closeResultsOverlay();
  document.body.insertAdjacentHTML('beforeend', html);
}

function closeResultsOverlay() {
  const old = document.querySelector('.search-results-overlay');
  if (old) old.remove();
}

function showNoResults(q) {
  closeResultsOverlay();
  const html = `<div class="search-results-overlay"><div class="search-results"><h3>Keine Ergebnisse</h3><p>Keine Treffer für „${escapeHtml(q)}“</p><button onclick="closeResultsOverlay()">Schließen</button></div></div>`;
  document.body.insertAdjacentHTML('beforeend', html);
}

function escapeHtml(unsafe) { return unsafe.replace(/[&<"']/g, function(m){return {'&':'&amp;','<':'&lt;','"':'&quot;',"'":'&#039;'}[m];}); }

// Secret modal functions
function openSecretModal() {
  const modal = document.getElementById('secret-modal');
  if (!modal) return;
  modal.style.display = 'flex';
  modal.setAttribute('aria-hidden','false');
  document.getElementById('site-search-input').value = '';
}

function closeSecretModal() {
  const modal = document.getElementById('secret-modal');
  if (!modal) return;
  modal.style.display = 'none';
  modal.setAttribute('aria-hidden','true');
}

function handleSecretSubmit(e) {
  e.preventDefault();
  document.getElementById('secret-contact-form').style.display = 'none';
  document.getElementById('secret-thanks').style.display = 'block';
  const data = {
    name: document.getElementById('secret-name').value,
    email: document.getElementById('secret-email').value,
    message: document.getElementById('secret-message').value,
    time: new Date().toISOString()
  };
  try { localStorage.setItem('secret_contact', JSON.stringify(data)); } catch(e){ console.warn('Local save failed', e); }
  return false;
}

document.addEventListener('click', function(e) {
  if (e.target && e.target.id === 'secret-close') closeSecretModal();
});

document.addEventListener('click', function(e) {
  const overlay = document.querySelector('.search-results-overlay .search-results');
  if (!overlay) return;
  if (!overlay.contains(e.target) && !e.target.closest('.search-form')) closeResultsOverlay();
});
