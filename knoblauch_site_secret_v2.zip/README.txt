
Alles über Knoblauch - statische Website (13 Seiten)
--------------------------------------------------

Diese Version enthält ein verstecktes Kontaktformular: gib im Suchfeld das genaue Passwort
"Lorik ist der größte" ein (ohne Anführungszeichen), dann öffnet sich das geheime Formular.

Deployment:
- Lokal: Ordner entpacken und index.html im Browser öffnen.
- GitHub Pages: Neues Repository anlegen, Dateien hochladen, in Settings -> Pages Branch 'main' aktivieren.
- Netlify/Vercel: Einfach das Verzeichnis deployen oder das Repository verbinden.
